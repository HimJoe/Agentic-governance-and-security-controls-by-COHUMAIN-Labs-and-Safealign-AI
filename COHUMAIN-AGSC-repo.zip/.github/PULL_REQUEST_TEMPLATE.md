## What this changes


## Type
- [ ] Editorial (typo/clarification/link)
- [ ] Mapping correction
- [ ] Control change (add / remove / re-scope)
- [ ] Tooling / website

## Checklist
- [ ] Updated `controls/CONTROLS.md` (if control content changed)
- [ ] Updated `controls/controls.json` and `controls/controls.csv`
- [ ] Updated framework crosswalk(s) in `frameworks/` if mappings changed
- [ ] Mappings cite the framework version
- [ ] Governance + security stay unified; scope preserved
