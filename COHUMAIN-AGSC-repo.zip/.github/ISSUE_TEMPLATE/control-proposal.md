---
name: Control proposal
about: Propose a new control or a change to an existing one
title: "[CONTROL] "
labels: control-proposal
---

**Pillar:** Safety / Alignment / Governance / Security

**Risk it closes** (ideally a MIT AI Risk Repository subdomain):

**Proposed objective** (one testable sentence):

**Key requirements:**
-

**Evidence that proves conformance:**
-

**Proposed mappings** (MIT / ATLAS / ATT&CK / EU / NIST / ISO):

**Why existing controls don't cover this:**
