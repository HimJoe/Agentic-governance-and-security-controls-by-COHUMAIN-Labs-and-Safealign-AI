---
name: Mapping correction
about: Flag an inaccurate or outdated framework mapping
title: "[MAPPING] "
labels: mapping
---

**Control ID:**

**Framework:** MIT AI Risk / MITRE ATLAS / MITRE ATT&CK / EU AI Act / NIST AI RMF / ISO 42001

**Current mapping:**

**Proposed mapping:**

**Source / framework version:**
